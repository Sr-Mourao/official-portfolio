"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getHeaders = exports.handlerCreated = exports.handlerNoContent = exports.handlerSuccess = exports.handlerError = void 0;
var handlerError = function (statusCode, message) { return ({
    statusCode: statusCode,
    headers: (0, exports.getHeaders)(),
    body: JSON.stringify({ message: message })
}); };
exports.handlerError = handlerError;
var handlerSuccess = function (result) { return ({
    statusCode: 200,
    headers: (0, exports.getHeaders)(),
    body: JSON.stringify(result)
}); };
exports.handlerSuccess = handlerSuccess;
var handlerNoContent = function () { return ({
    statusCode: 204,
    headers: (0, exports.getHeaders)(),
    body: JSON.stringify({})
}); };
exports.handlerNoContent = handlerNoContent;
var handlerCreated = function (result) { return ({
    statusCode: 201,
    headers: (0, exports.getHeaders)(),
    body: JSON.stringify(result)
}); };
exports.handlerCreated = handlerCreated;
var getHeaders = function () {
    return {
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': true,
        'Access-Control-Allow-Methods': 'HEAD,OPTIONS,POST,GET,PATCH,PUT',
    };
};
exports.getHeaders = getHeaders;
//# sourceMappingURL=response.js.map