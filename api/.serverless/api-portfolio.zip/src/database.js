"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.prismaClientDatabase = void 0;
var client_1 = require("@prisma/client");
var prismaClientDatabase = new client_1.PrismaClient();
exports.prismaClientDatabase = prismaClientDatabase;
//# sourceMappingURL=database.js.map